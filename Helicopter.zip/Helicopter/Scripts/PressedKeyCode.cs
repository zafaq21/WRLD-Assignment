public enum PressedKeyCode
{
    SpeedUpPressed,
    SpeedDownPressed,
    ForwardPressed,
    BackPressed,
    LeftPressed,
    RightPressed,
    TurnLeftPressed,
    TurnRightPressed
}